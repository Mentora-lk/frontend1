import { redirect } from 'next/navigation';

export default function Home() {
  redirect('/dashboard/admin/manage-users');
}
