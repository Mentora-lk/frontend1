'use client';

import { transactions } from '../../../../data/adminData';

function StatusBadge({ status }: { status: string }) {
  const palette =
    status === 'Success'
      ? { bg: '#ecfdf3', color: '#047857', border: '#a7f3d0' }
      : status === 'Pending'
      ? { bg: '#fff7ed', color: '#b45309', border: '#fed7aa' }
      : { bg: '#fef2f2', color: '#b91c1c', border: '#fecaca' };

  return (
    <span
      style={{
        padding: '4px 10px',
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 600,
        background: palette.bg,
        color: palette.color,
        border: `1px solid ${palette.border}`,
      }}
    >
      {status}
    </span>
  );
}

function StatCard({
  title,
  value,
  trendValue,
  accent,
  subtext,
}: {
  title: string;
  value: string;
  trendValue?: string;
  accent: string;
  subtext?: string;
}) {
  return (
    <div
      style={{
        background: '#ffffff',
        border: '1px solid #dcfce7',
        borderRadius: 16,
        padding: 20,
        boxShadow: '0 8px 20px rgba(0,0,0,0.04)',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <span style={{ width: 12, height: 12, borderRadius: 999, background: accent, display: 'inline-block' }} />
        {trendValue && <span style={{ fontSize: 12, color: '#16a34a', fontWeight: 600 }}>{trendValue}</span>}
      </div>
      <p style={{ margin: 0, color: '#6b7280', fontSize: 13, fontWeight: 600 }}>{title}</p>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 6 }}>
        <h3 style={{ margin: 0, color: '#065f46', fontSize: 28 }}>{value}</h3>
        {subtext && <span style={{ color: '#94a3b8', fontSize: 12 }}>{subtext}</span>}
      </div>
    </div>
  );
}

export default function PaymentsPage() {
  return (
    <div style={{ display: 'grid', gap: 20 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16 }}>
        <StatCard title="Total Platform Commission" value="LKR 450,200.00" trendValue="+12.5%" accent="#10b981" />
        <StatCard title="Pending Payouts to Tutors" value="LKR 125,800.00" subtext="Target: 200k" accent="#f59e0b" />
        <StatCard title="Total Transactions" value="1,284" trendValue="+5.7%" accent="#059669" />
      </div>

      <div
        style={{
          background: '#ffffff',
          border: '1px solid #d1fae5',
          borderRadius: 16,
          overflow: 'hidden',
          boxShadow: '0 10px 28px rgba(0,0,0,0.05)',
        }}
      >
        <div
          style={{
            padding: 20,
            borderBottom: '1px solid #ecfdf5',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 12,
          }}
        >
          <h3 style={{ margin: 0, color: '#065f46', fontSize: 18 }}>Transaction History</h3>
          <span style={{ fontSize: 13, color: '#6b7280' }}>Oct 1 - Oct 31, 2023</span>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 900 }}>
            <thead>
              <tr style={{ background: '#f0fdf4', textAlign: 'left' }}>
                {['Transaction ID', 'Student', 'Tutor', 'Amount (LKR)', 'Comm %', 'Revenue', 'Status', 'Actions'].map((h) => (
                  <th key={h} style={{ padding: '12px 16px', fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.04em', color: '#166534' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {transactions.map((txn, idx) => (
                <tr key={txn.id} style={{ borderTop: '1px solid #ecfdf5' }}>
                  <td style={{ padding: '12px 16px', color: '#6b7280', fontSize: 12, fontFamily: 'monospace' }}>{txn.id}</td>
                  <td style={{ padding: '12px 16px', color: '#14532d', fontWeight: 600 }}>
                    {txn.student}
                    <div style={{ fontSize: 12, color: '#9ca3af', fontWeight: 500 }}>ID: ST-00{idx + 41}</div>
                  </td>
                  <td style={{ padding: '12px 16px', color: '#14532d', fontWeight: 600 }}>
                    {txn.tutor}
                    <div style={{ fontSize: 12, color: '#9ca3af', fontWeight: 500 }}>ID: TR-10{idx + 92}</div>
                  </td>
                  <td style={{ padding: '12px 16px', textAlign: 'right', color: '#111827', fontWeight: 600 }}>{txn.amount.toFixed(2)}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right', color: '#6b7280' }}>{txn.comm}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right', color: '#059669', fontWeight: 700 }}>{txn.revenue.toFixed(2)}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                    <StatusBadge status={txn.status} />
                  </td>
                  <td style={{ padding: '12px 16px', textAlign: 'right', color: '#6b7280' }}>...</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{ padding: 16, borderTop: '1px solid #ecfdf5', display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: '#6b7280', fontSize: 13 }}>
          <span>Showing 1 to 4 of 1,284 transactions</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <button style={{ border: '1px solid #bbf7d0', background: '#fff', borderRadius: 8, padding: '4px 8px', color: '#166534' }}>{'<'}</button>
            <button style={{ border: '1px solid #10b981', background: '#10b981', borderRadius: 8, padding: '4px 10px', color: '#fff' }}>1</button>
            <button style={{ border: '1px solid #bbf7d0', background: '#fff', borderRadius: 8, padding: '4px 10px', color: '#166534' }}>2</button>
            <button style={{ border: '1px solid #bbf7d0', background: '#fff', borderRadius: 8, padding: '4px 8px', color: '#166534' }}>{'>'}</button>
          </div>
        </div>
      </div>
    </div>
  );
}
