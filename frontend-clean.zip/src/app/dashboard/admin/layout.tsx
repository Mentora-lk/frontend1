'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';

const adminLinks = [
  { href: '/dashboard/admin', label: 'Overview' },
  { href: '/dashboard/admin/manage-users', label: 'Manage Users' },
  { href: '/dashboard/admin/report', label: 'Report' },
  { href: '/dashboard/admin/auth', label: 'Admin Auth' },
  { href: '/dashboard/admin/signup', label: 'Admin Signup' },
];

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <>
      <style>{`
        .admin-shell { min-height: 100vh; background: #f8faf9; color: #1f2937; font-family: 'DM Sans', sans-serif; }
        .admin-wrap { display: flex; height: 100vh; overflow: hidden; }
        .admin-backdrop {
          position: fixed; inset: 0; background: rgba(17, 24, 39, 0.35); z-index: 30; border: none;
        }
        .admin-sidebar {
          position: fixed; inset: 0 auto 0 0; width: 260px; z-index: 40;
          background: linear-gradient(180deg, #064e3b 0%, #065f46 52%, #047857 100%);
          border-right: 1px solid rgba(16, 185, 129, 0.24);
          transform: translateX(-100%);
          transition: transform .2s ease;
        }
        .admin-sidebar.open { transform: translateX(0); }
        .admin-main { flex: 1; min-width: 0; display: flex; flex-direction: column; overflow: hidden; }
        .admin-header {
          height: 76px; display: flex; align-items: center; justify-content: space-between;
          padding: 0 20px; border-bottom: 1px solid rgba(16, 185, 129, 0.2);
          background: rgba(255, 255, 255, 0.88); backdrop-filter: blur(8px);
        }
        .admin-content {
          flex: 1; overflow-y: auto; padding: 24px; background:
            radial-gradient(1000px 300px at 15% -10%, rgba(16, 185, 129, 0.14), transparent 60%),
            radial-gradient(800px 260px at 95% -20%, rgba(5, 150, 105, 0.10), transparent 60%),
            #f8faf9;
        }
        .admin-inner { max-width: 1200px; margin: 0 auto; }
        .admin-brand {
          height: 76px; padding: 0 18px; border-bottom: 1px solid rgba(255, 255, 255, 0.15);
          display: flex; align-items: center; justify-content: space-between;
        }
        .admin-links { padding: 14px 10px; }
        .admin-link {
          display: block; margin-bottom: 8px; padding: 10px 12px; border-radius: 10px;
          color: #dcfce7; text-decoration: none; font-size: 14px; font-weight: 600;
          border: 1px solid transparent; transition: background .2s, border-color .2s, color .2s;
        }
        .admin-link:hover { background: rgba(4, 120, 87, 0.45); }
        .admin-link.active {
          background: linear-gradient(135deg, rgba(236, 253, 245, 0.2), rgba(209, 250, 229, 0.12));
          border-color: rgba(209, 250, 229, 0.35); color: #ecfdf5;
        }
        .admin-muted { color: #6b7280; font-size: 12px; }
        .admin-title { font-size: 18px; font-weight: 700; color: #065f46; }
        .admin-menu-btn, .admin-close-btn {
          border: 1px solid rgba(16, 185, 129, 0.24); background: rgba(16, 185, 129, 0.08);
          color: #065f46; border-radius: 10px; padding: 8px 11px; cursor: pointer;
        }
        .admin-close-btn { padding: 6px 10px; font-size: 12px; }
        @media (min-width: 768px) {
          .admin-backdrop { display: none; }
          .admin-sidebar { position: static; transform: none; }
          .admin-menu-btn, .admin-close-btn { display: none; }
          .admin-header { padding: 0 28px; }
          .admin-content { padding: 28px; }
        }
      `}</style>

      <div className="admin-shell">
        <div className="admin-wrap">
      {sidebarOpen && (
        <button
          type="button"
          className="admin-backdrop"
          onClick={() => setSidebarOpen(false)}
          aria-label="Close menu overlay"
        />
      )}

      <aside
        className={`admin-sidebar ${sidebarOpen ? 'open' : ''}`}
      >
        <div className="admin-brand">
          <div>
            <p style={{ fontSize: 15, color: '#ecfdf5', fontWeight: 700, margin: 0 }}>Mentora</p>
            <p style={{ margin: '2px 0 0', color: '#bbf7d0', fontSize: 12 }}>Admin Portal</p>
          </div>
          <button
            type="button"
            className="admin-close-btn"
            onClick={() => setSidebarOpen(false)}
            aria-label="Close menu"
          >
            Close
          </button>
        </div>

        <nav className="admin-links">
          {adminLinks.map((link) => {
            const active = pathname === link.href || pathname.startsWith(`${link.href}/`);
            return (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setSidebarOpen(false)}
                className={`admin-link ${active ? 'active' : ''}`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
      </aside>

      <main className="admin-main">
        <header className="admin-header">
          <button
            type="button"
            className="admin-menu-btn"
            onClick={() => setSidebarOpen(true)}
          >
            Menu
          </button>
          <h1 className="admin-title">Admin Dashboard</h1>
          <div className="admin-muted">Role: admin</div>
        </header>
        <div className="admin-content">
          <div className="admin-inner">
            {children}
          </div>
        </div>
      </main>
        </div>
      </div>
    </>
  );
}
