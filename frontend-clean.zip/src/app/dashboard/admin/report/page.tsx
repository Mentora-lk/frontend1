'use client';

import { useState } from 'react';
import { tutorVerifications } from '../../../../data/adminData';

type Tutor = typeof tutorVerifications[0];

function StatusBadge({ status }: { status: string }) {
  const palette =
    status === 'Verified'
      ? { bg: '#ecfdf3', color: '#047857', border: '#a7f3d0' }
      : status === 'Pending' || status === 'Pending Review' || status === 'Under Review'
      ? { bg: '#fffbeb', color: '#b45309', border: '#fde68a' }
      : { bg: '#fef2f2', color: '#b91c1c', border: '#fecaca' };

  return (
    <span
      style={{
        padding: '4px 10px',
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 600,
        background: palette.bg,
        color: palette.color,
        border: `1px solid ${palette.border}`,
      }}
    >
      {status}
    </span>
  );
}

function StatCard({ title, value, trendValue }: { title: string; value: string; trendValue?: string }) {
  return (
    <div
      style={{
        background: '#ffffff',
        border: '1px solid #dcfce7',
        borderRadius: 16,
        padding: 20,
        boxShadow: '0 8px 20px rgba(0,0,0,0.04)',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
        <span style={{ width: 12, height: 12, borderRadius: 999, background: '#10b981' }} />
        {trendValue && <span style={{ fontSize: 12, color: '#16a34a', fontWeight: 600 }}>{trendValue}</span>}
      </div>
      <p style={{ margin: 0, color: '#6b7280', fontSize: 13, fontWeight: 600 }}>{title}</p>
      <h3 style={{ margin: '6px 0 0', color: '#065f46', fontSize: 28 }}>{value}</h3>
    </div>
  );
}

export default function TutorsPage() {
  const [selectedTutor, setSelectedTutor] = useState<Tutor | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [subjectFilter, setSubjectFilter] = useState('Science');

  const filteredTutors = tutorVerifications.filter((tutor) => {
    const matchesSearch =
      tutor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tutor.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'All' || tutor.status === statusFilter;
    const matchesSubject = subjectFilter === 'All' || tutor.subject === subjectFilter;
    return matchesSearch && matchesStatus && matchesSubject;
  });

  return (
    <div style={{ display: 'grid', gap: 20 }}>
      <div>
        <h2 style={{ margin: 0, color: '#065f46', fontSize: 28, fontWeight: 800 }}>Tutor Verification</h2>
        <p style={{ margin: '6px 0 0', color: '#6b7280' }}>Review and approve tutor applications for the marketplace.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16 }}>
        <StatCard title="Pending Review" value="24" trendValue="+5% from yesterday" />
        <StatCard title="Verified Today" value="12" trendValue="-2% from yesterday" />
        <StatCard title="Total Tutors" value="1,402" trendValue="+1% growth" />
      </div>

      <div style={{ background: '#fff', border: '1px solid #dcfce7', borderRadius: 16, padding: 16 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr auto', gap: 10 }}>
          <input
            type="text"
            placeholder="Search by tutor name, email or NIC..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ padding: '11px 12px', borderRadius: 10, border: '1px solid #d1fae5', background: '#fff', fontSize: 14 }}
          />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ padding: '11px 12px', borderRadius: 10, border: '1px solid #d1fae5', background: '#fff', fontSize: 14 }}
          >
            <option value="All">Status: All</option>
            <option value="Pending">Pending</option>
            <option value="Verified">Verified</option>
            <option value="Missing Docs">Missing Docs</option>
          </select>
          <select
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            style={{ padding: '11px 12px', borderRadius: 10, border: '1px solid #d1fae5', background: '#fff', fontSize: 14 }}
          >
            <option value="All">Subject: All</option>
            <option value="Science">Science</option>
            <option value="Maths">Maths</option>
            <option value="IT">IT</option>
          </select>
          <button style={{ padding: '0 14px', borderRadius: 10, border: '1px solid #bbf7d0', background: '#ecfdf5', color: '#047857' }}>...</button>
        </div>
      </div>

      <div style={{ background: '#fff', border: '1px solid #d1fae5', borderRadius: 16, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 900 }}>
            <thead>
              <tr style={{ background: '#f0fdf4', textAlign: 'left' }}>
                {['Tutor Profile', 'Subjects', 'Location', 'Status', 'Actions'].map((h) => (
                  <th key={h} style={{ padding: '12px 16px', fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.04em', color: '#166534' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredTutors.map((tutor) => (
                <tr key={tutor.id} style={{ borderTop: '1px solid #ecfdf5' }}>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 38, height: 38, borderRadius: 999, background: '#ecfdf5', color: '#166534', display: 'grid', placeItems: 'center', fontWeight: 700 }}>
                        {tutor.name.charAt(0)}
                      </div>
                      <div>
                        <div style={{ color: '#14532d', fontWeight: 700 }}>{tutor.name}</div>
                        <div style={{ color: '#9ca3af', fontSize: 12 }}>{tutor.email}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ fontSize: 12, padding: '4px 8px', borderRadius: 8, background: '#ecfdf5', color: '#047857', border: '1px solid #bbf7d0' }}>{tutor.subject}</span>
                  </td>
                  <td style={{ padding: '12px 16px', color: '#6b7280' }}>📍 {tutor.location}</td>
                  <td style={{ padding: '12px 16px' }}><StatusBadge status={tutor.status} /></td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button
                      onClick={() => setSelectedTutor(tutor)}
                      style={{ border: 'none', background: 'none', color: '#059669', fontWeight: 600, cursor: 'pointer' }}
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{ padding: 16, borderTop: '1px solid #ecfdf5', display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: '#6b7280', fontSize: 13 }}>
          <span>Showing 1 to {filteredTutors.length} of 24 applications</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={{ border: '1px solid #bbf7d0', background: '#fff', borderRadius: 8, padding: '4px 10px', color: '#166534' }}>Previous</button>
            <button style={{ border: '1px solid #10b981', background: '#10b981', borderRadius: 8, padding: '4px 10px', color: '#fff' }}>1</button>
            <button style={{ border: '1px solid #bbf7d0', background: '#fff', borderRadius: 8, padding: '4px 10px', color: '#166534' }}>Next</button>
          </div>
        </div>
      </div>

      {selectedTutor && (
        <>
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.35)', zIndex: 40 }} onClick={() => setSelectedTutor(null)} />
          <div
            style={{
              position: 'fixed',
              top: 0,
              right: 0,
              width: '100%',
              maxWidth: 430,
              height: '100vh',
              zIndex: 50,
              background: '#ffffff',
              borderLeft: '1px solid #d1fae5',
              overflowY: 'auto',
              padding: 20,
              boxShadow: '-8px 0 30px rgba(0,0,0,0.08)',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3 style={{ margin: 0, color: '#065f46' }}>Verification Detail</h3>
              <button style={{ border: 'none', background: 'none', color: '#6b7280', cursor: 'pointer' }} onClick={() => setSelectedTutor(null)}>Close</button>
            </div>

            <div style={{ borderBottom: '1px solid #ecfdf5', paddingBottom: 14, marginBottom: 14 }}>
              <div style={{ color: '#14532d', fontWeight: 700, fontSize: 18 }}>{selectedTutor.name}</div>
              <div style={{ color: '#6b7280', fontSize: 13 }}>Applied: {selectedTutor.date}</div>
              <div style={{ marginTop: 8 }}><StatusBadge status="Under Review" /></div>
            </div>

            <div style={{ marginBottom: 14 }}>
              <p style={{ margin: '0 0 8px', color: '#374151', fontWeight: 700, fontSize: 13 }}>Identity Verification</p>
              <div style={{ border: '1px solid #d1fae5', borderRadius: 12, padding: 16, background: '#f9fffb', color: '#6b7280' }}>NIC Front Document</div>
            </div>

            <div style={{ marginBottom: 14 }}>
              <p style={{ margin: '0 0 8px', color: '#374151', fontWeight: 700, fontSize: 13 }}>Academic Credentials</p>
              <div style={{ border: '1px solid #d1fae5', borderRadius: 12, padding: 16, background: '#f9fffb', color: '#6b7280' }}>
                {selectedTutor.credentials || 'No document'}
              </div>
            </div>

            <div style={{ marginBottom: 14 }}>
              <p style={{ margin: '0 0 8px', color: '#374151', fontWeight: 700, fontSize: 13 }}>Internal Notes</p>
              <textarea
                placeholder="Add a note or reason for rejection..."
                rows={4}
                style={{ width: '100%', border: '1px solid #d1fae5', borderRadius: 12, padding: 12, resize: 'vertical' }}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <button onClick={() => setSelectedTutor(null)} style={{ border: '1px solid #fecaca', background: '#fff1f2', color: '#be123c', borderRadius: 10, padding: '10px 0', fontWeight: 700 }}>Reject</button>
              <button onClick={() => setSelectedTutor(null)} style={{ border: '1px solid #10b981', background: '#10b981', color: '#fff', borderRadius: 10, padding: '10px 0', fontWeight: 700 }}>Approve</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
