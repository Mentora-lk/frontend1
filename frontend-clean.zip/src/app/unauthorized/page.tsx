export default function UnauthorizedPage() {
  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Unauthorized</h1>
      <p>You do not have permission to access this page.</p>
    </main>
  );
}
